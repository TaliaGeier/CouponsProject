# `public interface CompaniesDAO`

An interface made to define the functions that the CompaniesDBDAO will implement.
 
 --------------------------------
 
# `public interface CouponsDAO`

An interface made to define the functions that the CouponsDBDAO will implement.
 
 --------------------------------
 
 # `public interface CustomersDAO`

An interface made to define the functions that the CustomersDBDAO will implement.
