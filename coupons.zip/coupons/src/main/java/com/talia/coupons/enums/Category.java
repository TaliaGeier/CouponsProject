package com.talia.coupons.enums;


/**
 * Category - is an enum, representing all categories.
 *
 */
public enum Category {
	COFFEE_SHOP,
	ELECTRONICS,
	RESTAURANTS,
	VACATION,
	CONCERTS,
	FOOTBALL_GAME,
	MOVIES,
	TRIPS,
	KIDS_ATTRACTIONS,
	FURNITURE,
	OPTICS,
	HAIR_SALONS,
	PUBLIC_TRANSPORTATION,
	COSMETIC_SURGERIES,
	PET_STORE
}

