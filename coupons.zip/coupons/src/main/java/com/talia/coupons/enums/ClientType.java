package com.talia.coupons.enums;


/**
 * ClientType - is an enum, representing all the types of clients.
 *
 */
public enum ClientType {
ADMINISTRATOR,
COMPANY,
CUSTOMER

}
